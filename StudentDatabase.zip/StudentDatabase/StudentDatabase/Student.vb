﻿Public Class Student
    Private _firstname As String
    Private _lastname As String
    Private _coursename As String
    Private _testgradeone As Integer
    Private _testgradetwo As Integer
    Private _testgradethree As Integer

#Region "Constructors"
    Public Sub New()
        'Default Constructor
        _firstname = ""
        _lastname = ""
        _coursename = ""
        _testgradeone = ""
        _testgradetwo = ""
        _testgradethree = ""

    End Sub

    Public Sub New(ByVal firstname As String, ByVal lastname As String, ByVal CourseName As String, ByVal TestGradeOne As Integer, ByVal TestGradeTwo As Integer, ByVal TestGradeThree As Integer)
        Me._firstname = firstname
        Me._lastname = lastname
        Me._coursename = CourseName
        Me._testgradeone = TestGradeOne
        Me._testgradetwo = TestGradeTwo
        Me._testgradethree = TestGradeThree
    End Sub
#End Region


#Region "Properties"
    Public Property Firstname As String
        Get
            Return _firstname
        End Get
        Set(value As String)
            _firstname = value
        End Set
    End Property
    Public Property Lastname As String
        Get
            Return _lastname
        End Get
        Set(value As String)
            _lastname = value
        End Set
    End Property
    Public Property CourseName As String
        Get
            Return _coursename
        End Get
        Set(value As String)
            _coursename = value
        End Set
    End Property
    Public Property GradeOne As Integer
        Get
            Return _testgradeone

        End Get
        Set(value As Integer)
            _testgradeone = value
        End Set
    End Property
    Public Property GradeTwo As Integer
        Get
            Return _testgradetwo

        End Get
        Set(value As Integer)
            _testgradetwo = value
        End Set
    End Property
    Public Property GradeThree As Integer
        Get
            Return _testgradethree

        End Get
        Set(value As Integer)
            _testgradethree = value
        End Set
    End Property
#End Region

End Class
