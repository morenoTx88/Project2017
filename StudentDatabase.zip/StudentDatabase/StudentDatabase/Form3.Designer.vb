﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.testThreeGrade = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.testTwoGrade = New System.Windows.Forms.TextBox()
        Me.testOneGrade = New System.Windows.Forms.TextBox()
        Me.courseOne = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txt_lastname = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btn_add = New System.Windows.Forms.Button()
        Me.txt_studentID = New System.Windows.Forms.TextBox()
        Me.txt_firstName = New System.Windows.Forms.TextBox()
        Me.lst_students = New System.Windows.Forms.ListBox()
        Me.deletebutton = New System.Windows.Forms.Button()
        Me.editbutton = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.testThreeGrade)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.testTwoGrade)
        Me.GroupBox1.Controls.Add(Me.testOneGrade)
        Me.GroupBox1.Controls.Add(Me.courseOne)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txt_lastname)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.btn_add)
        Me.GroupBox1.Controls.Add(Me.txt_studentID)
        Me.GroupBox1.Controls.Add(Me.txt_firstName)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(713, 211)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Student Information"
        '
        'testThreeGrade
        '
        Me.testThreeGrade.Location = New System.Drawing.Point(447, 89)
        Me.testThreeGrade.Name = "testThreeGrade"
        Me.testThreeGrade.Size = New System.Drawing.Size(42, 20)
        Me.testThreeGrade.TabIndex = 17
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(401, 93)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(40, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Test 3:"
        '
        'testTwoGrade
        '
        Me.testTwoGrade.Location = New System.Drawing.Point(353, 90)
        Me.testTwoGrade.Name = "testTwoGrade"
        Me.testTwoGrade.Size = New System.Drawing.Size(42, 20)
        Me.testTwoGrade.TabIndex = 15
        '
        'testOneGrade
        '
        Me.testOneGrade.Location = New System.Drawing.Point(259, 90)
        Me.testOneGrade.Name = "testOneGrade"
        Me.testOneGrade.Size = New System.Drawing.Size(42, 20)
        Me.testOneGrade.TabIndex = 14
        '
        'courseOne
        '
        Me.courseOne.Location = New System.Drawing.Point(90, 90)
        Me.courseOne.Name = "courseOne"
        Me.courseOne.Size = New System.Drawing.Size(108, 20)
        Me.courseOne.TabIndex = 10
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(307, 93)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(40, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Test 2:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(213, 93)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Test 1:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 93)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Course Name:"
        '
        'txt_lastname
        '
        Me.txt_lastname.Location = New System.Drawing.Point(90, 63)
        Me.txt_lastname.Name = "txt_lastname"
        Me.txt_lastname.Size = New System.Drawing.Size(591, 20)
        Me.txt_lastname.TabIndex = 9
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 66)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Last Name:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 43)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "First Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 19)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(61, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Student ID:"
        '
        'btn_add
        '
        Me.btn_add.Location = New System.Drawing.Point(519, 180)
        Me.btn_add.Name = "btn_add"
        Me.btn_add.Size = New System.Drawing.Size(162, 23)
        Me.btn_add.TabIndex = 3
        Me.btn_add.Text = "Add Student"
        Me.btn_add.UseVisualStyleBackColor = True
        '
        'txt_studentID
        '
        Me.txt_studentID.Location = New System.Drawing.Point(90, 16)
        Me.txt_studentID.Name = "txt_studentID"
        Me.txt_studentID.Size = New System.Drawing.Size(591, 20)
        Me.txt_studentID.TabIndex = 5
        '
        'txt_firstName
        '
        Me.txt_firstName.Location = New System.Drawing.Point(90, 40)
        Me.txt_firstName.Name = "txt_firstName"
        Me.txt_firstName.Size = New System.Drawing.Size(591, 20)
        Me.txt_firstName.TabIndex = 6
        '
        'lst_students
        '
        Me.lst_students.FormattingEnabled = True
        Me.lst_students.Location = New System.Drawing.Point(15, 255)
        Me.lst_students.Name = "lst_students"
        Me.lst_students.Size = New System.Drawing.Size(713, 173)
        Me.lst_students.TabIndex = 7
        '
        'deletebutton
        '
        Me.deletebutton.Location = New System.Drawing.Point(531, 434)
        Me.deletebutton.Name = "deletebutton"
        Me.deletebutton.Size = New System.Drawing.Size(162, 23)
        Me.deletebutton.TabIndex = 8
        Me.deletebutton.Text = "Delete Student"
        Me.deletebutton.UseVisualStyleBackColor = True
        '
        'editbutton
        '
        Me.editbutton.Location = New System.Drawing.Point(21, 434)
        Me.editbutton.Name = "editbutton"
        Me.editbutton.Size = New System.Drawing.Size(162, 23)
        Me.editbutton.TabIndex = 9
        Me.editbutton.Text = "Edit Student"
        Me.editbutton.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(280, 434)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(162, 23)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "Exit"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(746, 469)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.editbutton)
        Me.Controls.Add(Me.deletebutton)
        Me.Controls.Add(Me.lst_students)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form3"
        Me.ShowIcon = False
        Me.Text = "Student Database"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents btn_add As Button
    Friend WithEvents txt_studentID As TextBox
    Friend WithEvents txt_firstName As TextBox
    Friend WithEvents lst_students As ListBox
    Friend WithEvents deletebutton As Button
    Friend WithEvents editbutton As Button



    Private studentDatabase As Dictionary(Of Integer, Student)
    'Creates a Dictionary to hold the information of each student
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        studentDatabase = New Dictionary(Of Integer, Student)
    End Sub



    Private Sub btn_add_Click(sender As Object, e As EventArgs) Handles btn_add.Click
        'Checks if all fields have been filled 
        'If not then we ask the user to not have empty fields
        For Each c As Control In GroupBox1.Controls
            If (TypeOf c Is TextBox) Then
                Dim cText As TextBox = CType(c, TextBox)
                If (cText.Text.Equals("")) Then
                    MsgBox("All fields must be filled!")
                    Return
                End If
            End If
        Next

        'Adds the student to the dictionary with each line of information that was filled
        If (btn_add.Text.Equals("Add Student")) Then
            Dim studentToAdd As New Student(txt_firstName.Text, txt_lastname.Text, courseOne.Text,
                                            testOneGrade.Text, testTwoGrade.Text, testThreeGrade.Text)
            AddStudent(CInt(txt_studentID.Text), studentToAdd)
        End If
    End Sub

    'This checks if the ID number of a student that was entered already exists and if the ID exists
    'then we have the option of replacing that student with the new student
    Public Sub AddStudent(ByVal IDnumber As Integer, ByVal student As Student)
        If (studentDatabase.ContainsKey(IDnumber)) Then
            Dim studentToCheck As Student = studentDatabase.Item(IDnumber)
            Dim msgboxResult As DialogResult
            msgboxResult = MessageBox.Show("That ID number already exists! It belongs to: " &
                                           studentToCheck.Firstname & " " &
                                           studentToCheck.Lastname & " Would you like to replace this student?",
               "Replace?", MessageBoxButtons.YesNo)
            If (msgboxResult = DialogResult.Yes) Then
                'replace
                studentDatabase.Remove(IDnumber)
                studentDatabase.Add(IDnumber, student)
            End If
        Else
            studentDatabase.Add(IDnumber, student)
        End If
        'Refreshes the Dictionary to display an updated version
        RefreshListBox()
    End Sub


    'If a student needs to be remove then we click on the student and simply click the delete button
    Public Sub DeleteStudent(ByVal IDNumber As Integer)
        studentDatabase.Remove(IDNumber)
        'refreshes with updated information
        RefreshListBox()
    End Sub

    'How the display should output the information
    Public Sub RefreshListBox()
        lst_students.Items.Clear()

        For Each id As Integer In studentDatabase.Keys
            Dim student As Student = studentDatabase.Item(id)
            lst_students.Items.Add(id & ": " & student.Firstname & " " & student.Lastname &
                                   " |Course Name: " & student.CourseName & "| " & " |Test One Grade: " & student.GradeOne & "| " & " |Test Two Grade: " & student.GradeTwo & "| " & " |Test Three Grade: " & student.GradeThree & " |")
        Next

    End Sub





    Friend WithEvents txt_lastname As TextBox
    Friend WithEvents Label3 As Label

    Private Sub deletebutton_Click(sender As Object, e As EventArgs) Handles deletebutton.Click
        If Not (lst_students.SelectedItem Is Nothing) Then
            Dim studentInformation As String = lst_students.SelectedItem.ToString
            Dim studentID As Integer = CInt(studentInformation.Split(":")(0))
            DeleteStudent(studentID)
        End If
    End Sub

    Friend WithEvents testThreeGrade As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents testTwoGrade As TextBox
    Friend WithEvents testOneGrade As TextBox
    Friend WithEvents courseOne As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Button1 As Button

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class
